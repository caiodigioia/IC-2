#include <iostream>
#include <cstdlib>
#include <string.h>
using namespace std; 

int main(){
       int n, sucesso=0;
       char sb[106], s[100];
       
       cout<<"Entre com o tamanho da senha (maior que 1 e menor que 10): "<<endl;;
       cin>>n;
       if (n<2 || n>10){
          cout<<"Erro no tamanho da senha "<<endl;
          exit(1);
		}
       
       cout<<"Entre com a senha com "<<n<<" letras maiusculas : ";
       cin>>s;
       
       sucesso=system(strcat(strcpy(sb,"verif "),s));		// verifica se s eh a senha correta 
       														// retorna 1 em caso de sucesso 
       														// e 0 caso contrario
       
       if (sucesso==0)
          	cout<<"Senha incorreta "<<endl;
       else
        	cout<<"Sucesso! Senha: "<<s<<endl;
             
       
       return(0);
	
}
